
public class FileDetail {
	private String name;
	private String path;
	public FileDetail(String name, String path) {
		super();
		this.name = name;
		this.path = path;
	}
	public String getName() {
		return name;
	}
	public String getPath() {
		return path;
	}
	
}
