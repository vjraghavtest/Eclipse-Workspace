import java.io.Serializable;

public class FileDetails implements Serializable {
	private String name, checksum, owner, path;
	private long filesize;

	public FileDetails(String name, String checksum, String owner, String path, long filesize) {
		super();
		this.name = name;
		this.checksum = checksum;
		this.owner = owner;
		this.path = path;
		this.filesize=filesize;
	}

	public long getFilesize() {
		return filesize;
	}

	public String getName() {
		return name;
	}

	public String getChecksum() {
		return checksum;
	}

	public String getOwner() {
		return owner;
	}

	public String getPath() {
		return path;
	}

}
